<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email</title>
</head>
<body>
    <h1>you have requested password </h1>
    <p>your token is <strong><?php echo e($token); ?></strong></p>
    <p>Thank you</p>
</body>
</html><?php /**PATH G:\claimpaulPro\Claim Paul Backend\resources\views/reset_password.blade.php ENDPATH**/ ?>